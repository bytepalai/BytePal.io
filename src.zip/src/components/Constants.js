/*
 Copyright © 2020 BYTEPAL AI, LLC And Its Affiliates. All rights reserved.
*/

const hostname =   'https://api.bytepal.io/'

export default hostname ;
